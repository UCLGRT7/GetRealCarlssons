using System;

public class CombinedProjectData
{
    public string? CaseNumber { get; set; }
    public string? CustomerName { get; set; }
    public DateTime? OfferSentDate { get; set; }
    public DateTime? LastModified { get; set; }
    public DateTime? Deadline { get; set; }
    public DateTime? Paid { get; set; }
    public string Status { get; set; }
    public string OfferApproved { get; set; }
    public string IsPaymentRecieved { get; set; }




}
