
using System.Collections.Generic;
using System.IO;

namespace CarlssonsWPF.FileService
{
    public static class FileService
    {
        //public static void Save<T>(string filePath, List<T> data)
        //{
        //    var json = JsonConvert.SerializeObject(data, Formatting.Indented);
        //    File.WriteAllText(filePath, json);
        //}

        //public static List<T> Load<T>(string filePath)
        //{
        //    if (!File.Exists(filePath)) return [];
        //    var json = File.ReadAllText(filePath);
        //    return JsonConvert.DeserializeObject<List<T>>(json) ?? new List<T>();
        //}
    }
}
